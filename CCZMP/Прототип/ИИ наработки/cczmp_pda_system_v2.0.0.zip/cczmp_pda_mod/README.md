# CCZMP PDA SYSTEM v1.0.0
## Мод для S.T.A.L.K.E.R. ТЧ — Трилогия Апокалипсис

---

## СТРУКТУРА ФАЙЛОВ

```
gamedata/
├── scripts/
│   ├── pda_core.script           ← Ядро: реестр, типы КПК, структуры данных
│   ├── pda_communication.script  ← Звонки, SMS, контакты (онлайн/оффлайн)
│   ← pda_hacking.script          ← Взлом: брутфорс, пентест, терминал Kali
│   ├── pda_malware.script        ← Вредоносное ПО: майнер, криптограф, RAT
│   └── pda_init.script           ← Точка входа, патч bind_stalker, команды
├── configs/
│   ├── misc/pda_devices.ltx      ← LTX конфиги предметов КПК
│   └── text/rus/string_table_pda.xml ← Строки интерфейса (русский)
└── README.md                     ← Этот файл
```

---

## УСТАНОВКА

1. Скопировать папку `gamedata/` в корень игры
2. Убедиться что в `fsgame.ltx` включена строка:
   ```
   $game_data$ = true| true| $fs_root$| gamedata\
   ```
3. Запустить игру — мод активируется автоматически

### Если у тебя уже есть свой bind_stalker.script:
Патч применяется автоматически через `cczmp_patch_bind_stalker()` в `pda_init.script`.
Если патч не сработал — добавь в свой `bind_stalker.script`:

```lua
-- В функцию net_spawn актора:
cczmp_pda_hook_actor_spawn(self.object)

-- В функцию update актора:
cczmp_pda_hook_actor_update(self.object, delta)
```

### Подключить к LTX системе предметов:
В файле `gamedata/configs/misc/items.ltx` добавь строку:
```
#include "pda_devices.ltx"
```

### Подключить строки:
В файле `gamedata/configs/text/rus/string_table.xml` добавь:
```xml
<include file="string_table_pda.xml"/>
```

---

## КОНСОЛЬНЫЕ КОМАНДЫ (debug)

Открой консоль X-Ray (~) и вводи:

```lua
-- Список всех КПК
lua cczmp_list_pdas()

-- Статус КПК
lua cczmp_status("@player")
lua cczmp_status("380441000001")

-- Отправить SMS
lua cczmp_sms("@player", "380441000001", "Привет, Воронин!")
lua cczmp_sms("380441000001", "@player", "Ответ от Воронина")

-- Позвонить
lua cczmp_call("@player", "380441000001")

-- Взломать КПК (только с хакерским КПК)
lua cczmp_hack("@hacker_pda_num", "380441000010")

-- Установить вредоносное ПО
lua cczmp_infect("@hacker", "380441000010", "xmrig_miner")
lua cczmp_infect("@hacker", "380441000010", "ransomware")
```

---

## ТИПЫ КПК

| Предмет        | Защита       | Взлом        | Интерфейс       |
|----------------|--------------|--------------|-----------------|
| `pda_budget`   | Нет          | 3 сек        | POCO/Honor      |
| `pda_mid`      | PIN          | 15 сек       | Android 10/11   |
| `pda_elite`    | AES-256      | 60 сек / 40% | iOS 18          |
| `pda_elite_mvd`| 2FA аппарат  | Невозможно   | iOS 18 + МВД    |
| `pda_hacker`   | Нет (хакер)  | —            | Kali Linux      |

---

## ТИПЫ МАЛВАРЕЙ

| Тип          | Название          | Эффект                             |
|--------------|-------------------|------------------------------------|
| `xmrig_miner`| XMRig 6.20.0      | Дренаж батареи 2%/30сек            |
| `ransomware` | LockBit 3.0 Sim   | Шифрует данные, требует выкуп      |
| `remote_access`| DarkComet RAT   | Удалённый доступ для хакера        |
| `keylogger`  | SpyNote 7         | Перехват всех сообщений            |
| `backdoor`   | Cobalt Strike     | Постоянный скрытый доступ          |
| `data_wiper` | Shamoon 3.0       | Уничтожает все данные КПК          |
| `ddos_bot`   | Mirai Variant     | Флуд сообщениями всем контактам    |

---

## ОНЛАЙН-РЕЖИМ (КРМП)

В файле `pda_communication.script` измени:
```lua
pda_comm.OFFLINE_MODE = false  -- строка 20
```

Затем заполни заглушки в разделе "РАЗДЕЛ 6: ОНЛАЙН API":
```lua
function pda_comm.online_send_message(sender, target, msg)
    -- Вставь вызов API твоего КРМП фреймворка
    server.send_event("pda_message", { ... })
end
```

---

## СЛЕДУЮЩИЕ МОДУЛИ (в разработке)

- `pda_ui_budget.script`  — UI бюджетного КПК (XML + Lua)
- `pda_ui_mid.script`     — UI среднего КПК
- `pda_ui_elite.script`   — UI элитного / МВД
- `pda_ui_hacker.script`  — Терминал Kali Linux (полноэкранный)
- `pda_2fa.script`        — Протокол МВД 2FA (расширенный)

---

## АВТОРЫ

CCZMP RP Project — Долг: Философия Войны
Движок: X-Ray Engine (S.T.A.L.K.E.R. ТЧ, Трилогия Апокалипсис)
